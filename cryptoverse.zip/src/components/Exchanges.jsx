import React from 'react'

const Exchanges = () => {
  return (
    <div>
      
    </div>
  )
}

export default Exchanges
